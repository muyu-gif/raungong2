# 活动智囊 · 前端交付包

## 内容

- `docs/04-前端开发文档.md`：按当前后端真实返回格式编写的前端联调文档
- `contracts/openapi.current.json`：当前实际后端导出的 OpenAPI（13 个操作）
- `examples/plan_welcome_party.json`：Mock 标准数据

## 后端地址

- 本地：`http://127.0.0.1:8000`
- Swagger：`http://127.0.0.1:8000/docs`
- 健康检查：`http://127.0.0.1:8000/healthz`

## 给前端的话

先看 `docs/04-前端开发文档.md` 第 2 节能力矩阵和第 13 节差异清单。

`docs/03-接口规范.md` 是目标契约，不是当前实现；当前以本包为准。

当前已实现：登录、枚举、生成、轮询、列表、详情、按节编辑、复制、删除、Markdown 导出。

后端已实现 LangGraph 三节点 + DeepSeek + BM25 RAG，并完成真实 API 生成验证；Mock 仍可用于无 Key 演示。

当前未实现：版本历史、重新生成某一节、模板、PDF。
